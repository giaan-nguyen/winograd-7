// Giaan Nguyen - 1438324
// ECE 3331 - Program 07
/* This program takes in a filename (and path) - inputted by the user as a string - to test the .wav extension. If the input contains the .wav extension,
assuming the input is an existing file, the program will display the audio characteristics of the .wav file. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int checkExt(char *path);

main()
{
	char filename[260]; // longest file path allowed is ~260 chars
	printf("This program identifies the audio characteristics of an inputted .wav file.\n");
	
	input:
	printf("Please enter a filename (and path, if necessary) for a .wav audio file: \n");
	scanf("%s", filename);
	
	//CHECK .WAV EXTENSION
	if( checkExt(filename) ){
		printf("\nInvalid file extension. Please try again.\n");
		goto input;
	}
	
	//OPEN AND READ FILE
	FILE *fp;
	fp = fopen(filename, "rb");
	if(fp == NULL){
		printf("\nInvalid filename. Please try again.\n");
		goto input;
	}
	char *header;
	header = (char *)malloc(44);
	fread(header, 1, 44, fp);
	
	//AUDIO CHARACTERISTICS
	char *chunkid, *format, *subchunk1id, *subchunk2id;
	unsigned int *chunksize, *subchunk1size, *subchunk2size;
	unsigned short int *audioformat, *numchannels, *blockalign, *bitspersample;
	unsigned int *samplerate, *byterate;
	char *data;
	printf("\nThe following are the audio characteristics of the file \"%s\":\n\n", filename);
	
	chunkid = header;
	printf("ChunkID = %c%c%c%c\n", *chunkid, *(chunkid + 1), *(chunkid + 2), *(chunkid + 3));
	
	chunksize = (int *)(header + 4);
	printf("ChunkSize (in bytes) = %d\n", *chunksize);
	
	format = header + 8;
	printf("Format = %c%c%c%c\n", *format, *(format + 1), *(format + 2), *(format + 3));
	
	subchunk1id = header + 12;
	printf("Subchunk1ID = %c%c%c%c\n", *subchunk1id, *(subchunk1id + 1), *(subchunk1id + 2), *(subchunk1id + 3));
	
	subchunk1size = (int *)(header + 16);
	printf("Subchunk1Size (in bytes) = %d\n", *subchunk1size);
	
	audioformat = (short int *)(header + 20);
	printf("AudioFormat = %hd\n", *audioformat);
	
	numchannels = (short int *)(header + 22);
	printf("NumChannels = %hd\n", *numchannels);
	
	samplerate = (int *)(header + 24);
	printf("SampleRate = %d\n", *samplerate);
	
	byterate = (int *)(header + 28);
	printf("ByteRate = %d\n", *byterate);
	
	blockalign = (short int *)(header + 32);
	printf("BlockAlign = %hd\n", *blockalign);
	
	bitspersample = (short int *)(header + 34);
	printf("BitsPerSample = %hd\n", *bitspersample);
	
	subchunk2id = header + 36;
	printf("Subchunk2ID = %c%c%c%c\n", *subchunk2id, *(subchunk2id + 1), *(subchunk2id + 2), *(subchunk2id + 3));
	
	subchunk2size = (int *)(header + 40);
	printf("Subchunk2Size (in bytes) = %d\n\n", *subchunk2size);	
	
	//FINISH
	printf("Execution is now complete. The program will now close.\n");
	fclose(fp);
	return;
	system("pause");
}

int checkExt(char *path){
	char temp[5];
	int i;
	//RETRIEVE FILE EXTENSION
	for(i=0; i<4; i++) temp[i] = path[strlen(path) - (4 - i)];
	temp[5] = '\0';
	
	//CHECK FOR .WAV EXTENSION
	if( temp[0] != '.' ) return 1;
	if( temp[1] != 'w' && temp[1] != 'W' ) return 1; 
	if( temp[2] != 'a' && temp[2] != 'A' ) return 1;
	if( temp[3] != 'v' && temp[3] != 'V' ) return 1;
	
	//SUCCESS
	return 0;
}
