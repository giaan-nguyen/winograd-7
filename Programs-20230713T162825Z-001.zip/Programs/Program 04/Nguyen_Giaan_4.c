#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* This program approximates the fourth root of a number using the Newton-Raphson algorithm. */
double fun(double x, double c);
double deriv(double x);
double newton(double x, double c);
main()
{
	double c0,iguess,tol,error;
	int iter,i;
	printf("Please input a number to approximate the fourth root of:\n");
	scanf("%lf",&c0);
	printf("Please input an initial guess for the fourth root:\n");
	scanf("%lf",&iguess);
	
	printf("Please input a tolerance such that the program will stop running once the error is within the tolerance:\n");
	scanf("%lf",&tol);
	printf("Please input the maximum number of iterations the program will run, assuming it does not reach within tolerance:\n");
	scanf("%d",&iter);
	
	for(i=0;i<=iter;i++){
		// printf("Iteration %d gives %lf\n",i,iguess);
		// To track the values at each iteration, de-comment the line of code above.
		error=fabs(fun(iguess,c0));
		if(error>=tol){
			iguess=newton(iguess,c0);
		}
		else break;
	}
	printf("After %d iterations out of the maximum %d allowed iterations,\n",i,iter);
	printf("the fourth root of %lf is calculated to be approximately %lf,\n",c0,iguess);
	printf("with a final error of %lf given a suggested tolerance of %lf.\n",error,tol);
	system("pause");
}

double fun(double x, double c){
	double y;
	y=x*x*x*x-c;
	return y;
}

double deriv(double x){
	double dy;
	dy=4.0*x*x*x;
	return dy;
}

double newton(double x, double c){
	double x1;
	x1=x-fun(x,c)/deriv(x);
	return x1;
}
