// Giaan Nguyen - 1438324
// ECE 3331 - Program 08

/*This program creates a .wav file based on the user input for filename and duration. Since randomly generated values are recorded, 
the .wav file will playback as white noise.*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

FILE* openfile(FILE *fp);
void getlength(float *length);
void fillaudio(short int *data, int num_samp);
void int2char(int n, char *x);
void short2char(short int n, char *x);

main()
{
	//ACCESS .WAV FILE TO WRITE
	printf("This program will generate a .wav file comprised of white noise.\n");
	FILE *fp;
	fp = openfile(fp);
	
	//GET TIME OF SAMPLE
	float length;
	getlength(&length);
	
	//CREATE 1D ARRAY 
	short int *audiodat;
	int num_samples;
	unsigned short int numchannels = 2, bitspersample = 16;
	unsigned int samplerate = 44100;
	num_samples = length * (float)samplerate * numchannels;
	audiodat = (short int *)malloc( num_samples * sizeof(short int) );
	
	//FILL IN DATA INTO ARRAY
	fillaudio(audiodat, num_samples);
	
	//CREATE .WAV HEADER
	printf("\nInitializing....\n");
	unsigned char *wh;
	wh = (unsigned char *)malloc( 44 * sizeof(unsigned char) );
	unsigned int subchunk1size = 16, subchunk2size;
	subchunk2size = num_samples * bitspersample / 8; // numchannels taken care of in num_samples, so no need to multiply
	// fmt subchunk
	strncpy( wh + 12, "fmt ", 4 ); 		//subchunk1id
	int2char(subchunk1size, wh + 16);	//subchunk1size
	short2char(1, wh + 20);				//audioformat
	short2char(numchannels, wh + 22);	//numchannels
	int2char(samplerate, wh + 24);		//samplerate
	int2char(samplerate * numchannels * bitspersample / 8, wh + 28);	//byterate
	short2char(numchannels * bitspersample / 8, wh + 32);		//blockalign
	short2char(bitspersample, wh + 34);		//bitspersample
	// data subchunk
	strncpy( wh + 36, "data", 4 );		//subchunk2id
	int2char(subchunk2size, wh + 40);	//subchunk2size
	// RIFF chunk
	strncpy( wh, "RIFF", 4 );	// chunkid
	int2char(4 + (8 + subchunk1size) + (8 + subchunk2size), wh + 4); // chunksize
	strncpy( wh + 8, "WAVE", 4 );	//format
	
	//WRITE TO FILE
	printf("\nWriting to file....\n");
	fwrite(wh, 1, 44, fp);
	fwrite(audiodat, 2, num_samples, fp);
	printf("%d bytes total.\n", 44 * sizeof(unsigned char) + num_samples * sizeof(short int));
	
	printf("\nFile completed. The program will now exit.\n");
	fclose(fp);
	return;
	system("pause");
}

FILE* openfile(FILE *fp){
	//PROMPT USER ACTION
	char filename[260], temp[5]; // longest file path allowed is ~260 chars
	input:
	printf("Please enter a .wav file to write to: ");
	scanf("%s", filename);
	
	//RETRIEVE EXTENSION
	int i;
	for(i=0; i<5; i++) temp[i] = filename[strlen(filename) - (4 - i)];
	
	//CHECK FOR .WAV EXTENSION
	if( ( temp[0] != '.' ) || ( temp[1] != 'w' && temp[1] != 'W' ) || ( temp[2] != 'a' && temp[2] != 'A' ) || ( temp[3] != 'v' && temp[3] != 'V' ) ){
		printf("\nInvalid file extension. Please try again.\n");
		goto input;
	} 
	return fopen(filename, "wb");
}

void getlength(float *len){
	printf("\nPlease enter the desired duration of sample (in seconds): ");
	scanf("%f", len);
}

void fillaudio(short int *data, int num_samp){
	int i;
	srand( (unsigned int)time(NULL) );
	for( i = 0; i < num_samp; i++ ) {
		data[i] = ((float)2.0 * ( (float)rand() / (float)RAND_MAX - (float)0.5 )) * (float)32767;
	}
}

void int2char(int n, char *x){
	x[0] = n % 256;
	x[1] = ( (int)(n / 256) ) % 256;
	x[2] = ( (int)(n / (256 * 256) ) ) % 256;
	x[3] = ( (int)(n / (256 * 256 * 256) ) ) % 256;
}

void short2char(short int n, char *x){
	x[0] = n % 256;
	x[1] = ( (int)(n / 256) ) % 256;
}
