// Giaan Nguyen - 1438324
// ECE 3331 - Program 02
/* This program will read in a file containing a list of integers and determine the number of occurrences 
of some integer (provided by the user) within the list. */

#include <stdio.h>
#include <stdlib.h>

main()
{
	printf("This program will count the number of occurrences some inputted integer is found within a file a containing a list of integers.\n\n");
	int ix,iref,count=0,total=0;
	FILE* fpi;
	fpi=fopen("in.txt","r");
	
	if(fpi == NULL){
		printf("The file in.txt did not successfully open.\n");
		return;
	}
	
	printf("Enter an integer: \n");
	scanf("%d",&ix);
	
	while(fscanf(fpi,"%d",&iref)==1){
		total++;
		if(iref == ix){
			count++;
		}	
	}
	
	printf("The integer %d was found in the file %d times. There are %d total number of integers within the file.\n",ix,count,total);
	system("pause");
}
