// Giaan Nguyen - 1438324
// ECE 3331 - Program 09
/* This program takes a mono .wav file and outputs a stereo .wav file with added flange effect. */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define A 	0.9		// A <= 1.0
#define fo 	0.8		// fo is some small frequency

struct wavheader{
		char chunkid[4];
		unsigned int chunksize;
		char format[4];
		char subchunk1id[4];
		unsigned int subchunk1size;
		unsigned short int audioformat;
		unsigned short int numchannels;
		unsigned int samplerate;
		unsigned int byterate;
		unsigned short int blockalign;
		unsigned short int bitspersample;
		char subchunk2id[4];
		unsigned int subchunk2size;
};
	
FILE* infile(FILE *fp, struct wavheader *inputwav);
FILE* outfile(FILE *fp);

main()
{
	FILE *fpi, *fpo;
	struct wavheader wh[2];
	fpi = infile(fpi, &wh[0]);
	fpo = outfile(fpo);
	
	//CHANGE SOME AUDIO CHARACTERISTICS FOR STEREO
	wh[1] = wh[0];
	wh[1].numchannels = 2;
	wh[1].byterate = wh[1].numchannels * wh[1].byterate;
	wh[1].blockalign = wh[1].numchannels * wh[1].blockalign;
	wh[1].subchunk2size = wh[1].numchannels * wh[1].subchunk2size;
	wh[1].chunksize = 36 + wh[1].subchunk2size;
	
	//CREATE ARRAY FOR AUDIO INPUT, TWO ARRAYS FOR STEREO OUTPUT
	short int *audiodat, *leftdat, *rightdat;
	int num_samples;
	num_samples = (wh[0].subchunk2size) / (wh[0].numchannels) / (wh[0].bitspersample) * 8;
	audiodat = (short int *)malloc( num_samples * sizeof(short int) );
	leftdat = (short int *)malloc( num_samples * sizeof(short int) );
	rightdat = (short int *)malloc( num_samples * sizeof(short int) );
	fread(audiodat, sizeof(short int), num_samples, fpi);
	
	//WRITE TO OUTPUT FILE
	fwrite(&wh[1], sizeof(struct wavheader), 1, fpo);
	
	// To create stereo version of mono file, de-comment the lines below and comment the lines for flange
	/*
	int i;
	for(i = 0; i < num_samples; i++){
		leftdat[i] = audiodat[i];
		rightdat[i] = audiodat[i];
		fwrite(&leftdat[i], sizeof(short int), 1, fpo);
		fwrite(&rightdat[i], sizeof(short int), 1, fpo);
	}
	*/
	
	// FLANGE
	int n, dl, dr;
	unsigned int fs;
	fs = wh[0].samplerate;
	for(n = 0; n < num_samples; n++){
		dl = n - (int)(44 * ( 1 + A * cos(2 * 3.14159265 * fo * n / fs) ));
		dr = n - (int)(44 * ( 1 + A * sin(2 * 3.14159265 * fo * n / fs) ));
		if(dl < 0) dl = n;
		if(dr < 0) dr = n;
		leftdat[n] = (audiodat[n] + 0.7 * audiodat[dl]) / (1.0 + 0.7);
		rightdat[n] = (audiodat[n] + 0.7 * audiodat[dl]) / (1.0 + 0.7);
		fwrite(&leftdat[n], sizeof(short int), 1, fpo);
		fwrite(&rightdat[n], sizeof(short int), 1, fpo);
	}
	
	fclose(fpi);
	fclose(fpo);	
	system("pause");
}	

FILE* infile(FILE *fp, struct wavheader *inputwav){
	//PROMPT USER ACTION
	char filename[260]; // longest file path allowed is ~260 chars
	input:
	printf("Please enter a mono .wav file to read from: ");
	scanf("%s", filename);
	
	//CHECK IF FILE EXISTS
	fp = fopen(filename, "rb");
	if(fp == NULL){
		printf("\nFile does not exist.\n");
		goto input;
	}
	
	//READ IN FILE	
	fread(inputwav, 44, 1, fp);
	if( ((*inputwav).bitspersample != 16) || ((*inputwav).numchannels != 1) ){
		printf("\nInvalid format.\n");
		goto input;
	}
	return fp;
}

FILE* outfile(FILE *fp){
	//PROMPT USER ACTION
	char filename[260]; // longest file path allowed is ~260 chars
	printf("Please enter a .wav file to write to: ");
	scanf("%s", filename);
	fp = fopen(filename, "wb");
	return fp;
}
