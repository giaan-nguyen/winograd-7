// Giaan Nguyen - 1438324 
// ECE 3331 - Program 01

#include <stdio.h>
#include <stdlib.h>

main()
{ 
	int ix,iy,ireturn;
	printf("This program checks if the sequence of integers the user inputs is monotonically increasing.\n");
	printf("At any point, press ctrl+z to exit the program. ");
	printf("Enter an integer: \n");
	ireturn=scanf("%d",&ix);
	
	while (ireturn!=EOF){
		printf("You have entered %d. Enter another integer: \n",ix);
		ireturn=scanf("%d",&iy);
		if (iy>ix && ireturn!=EOF){
			ix=iy;
		}
		else if (iy<=ix && ireturn!=EOF){
			printf("The sequence is no longer monotonically increasing. ");
			ireturn=-1;
		}
		else 
			printf("The user has pressed ctrl+z. ");
	}
	
	printf("The program will now exit.\n");
	system("pause");
	
}
