// Giaan Nguyen - 1438324
// ECE 3331 - Program 10

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

void assignmatrix(float **matr, int row, int col);
float innerprod(float **matr1, float **matr2, float **prod, int row, int col);

main()
{
	printf("This program will perform the inner product of two matrices of the same \ndimensions, W x H.\n\n");
	printf("That is, element-wise multiplication will be operated on two W x H matrices, \nA and B. Then the sum of the product's elements is computed.\n\n");
	printf("NOTE: for matrices to print neatly onto the window, dimension H <= 5 is \nhighly suggested.\n\n");
	
	int W, H;
	printf("Please enter a positive integer value for the dimension W: ");
	scanf("%d", &W);
	printf("Please enter a positive integer value for the dimension H: ");
	scanf("%d", &H);
	
	float **A, **B, **AB, sum;
	int i;
	printf("\nPseudo-random float values from the range 0.0 to (W * H) for the elements of \nmatrices A and B are assigned.\n\n");
	system("pause");
	srand( (unsigned int)time(NULL) );
	
	A = (float **)malloc( W * sizeof(float *) );
	for(i = 0; i < W; i++) A[i] = (float *)malloc ( H * sizeof(float) );
	printf("\n\n\n\nMatrix A is printed below: \n\n");
	assignmatrix(A, W, H);
	system("pause");
	
	B = (float **)malloc( W * sizeof(float *) );
	for(i = 0; i < W; i++) B[i] = (float *)malloc ( H * sizeof(float) );
	printf("\n\n\n\nMatrix B is printed below: \n\n");
	assignmatrix(B, W, H);
	system("pause");
	
	AB = (float **)malloc( W * sizeof(float *) );
	for(i = 0; i < W; i++) AB[i] = (float *)malloc( H* sizeof(float) );
	printf("\n\n\n\nThe element-wise multiplication of A and B, defined as AB, is printed below: \n\n");
	sum = innerprod(A, B, AB, W, H);
	system("pause");
	
	printf("\n\n\n\nThe inner product of A and B is %f.\n", sum);
	printf("\nNotice how the inner product of A and B is just the sum of the elements \nof the product AB from element-wise multiplication.\n\n");
	return;
	system("pause");
	
}

void assignmatrix(float **matr, int row, int col){
	int i, j;
	for(i = 0; i < row; i++){
		for(j = 0; j < col; j++){
			matr[i][j] = (float)rand() / (float)RAND_MAX * ((float)row * (float)col);
			printf("%f\t", matr[i][j]);
		}
		printf("\n\n");
	}
}

float innerprod(float **matr1, float **matr2, float **prod, int row, int col){
	int i, j;
	float sum = 0.0;
	for(i = 0; i < row; i++){
		for(j = 0; j < col; j++){
			prod[i][j] = matr1[i][j] * matr2[i][j];
			sum += prod[i][j];
			printf("%f\t", prod[i][j]);
		}
		printf("\n\n");
	}
	return sum;
}
