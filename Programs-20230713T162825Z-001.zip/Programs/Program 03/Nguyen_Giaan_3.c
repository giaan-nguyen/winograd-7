// Giaan Nguyen - 1438324
// ECE 3331 - Program 03
/* This program - when asked to encode - will read in a file full of text and will only encode lowercase letters, digits, blank space, period, and line feed. 
All other characters will be ignored. Similarly, when asked to decode, the program will decode characters corresponding to the above list. */ 

#include <stdio.h>
#include <stdlib.h>

main()
{
	printf("This program will encode or decode a message within an input file, depending on what the user decides to do.\n");
	FILE *fpi,*fpo;
	fpi=fopen("in.txt","r"); // reads in input file
	fpo=fopen("out.txt","w"); // writes to output file
	
	char msg;
	while(1){
		printf("Please enter 'e' to encode or 'd' to decode a message: ");
		scanf("%c%*c",&msg); // reads first character, ignores second character (when enter key is hit) 
		if(msg=='e') goto encode;
		else if(msg=='d') goto decode;
	}
	
	encode:
	printf("\nThe user has opted to encode the message.\n");
	int escan,eref;
	while(fscanf(fpi,"%c",&escan)==1){
		if(escan>=97 && escan<=122) eref=1; // lowercase letters
		else if(escan>=48 && escan<=57) eref=2; // digits
		else eref=escan;
		switch(eref){
			case 1: {
				fprintf(fpo,"%c",escan-64);
				break;
			}
			case 2: {
				fprintf(fpo,"%c",escan+11);
				break;
			}
			case 32: {
				fprintf(fpo,"%c",69); // blank space
				break;
			}
			case 46: {
				fprintf(fpo,"%c",70); // period
				break;
			}
			case 10: {
				fprintf(fpo,"%c",71); // LF
				break;
			}
		}
	}
	printf("The encoding process is now complete. Please check the output file.\n");
	system("pause");
	return;
	
	decode:
	printf("\nThe user has opted to decode the message.\n");
	int dscan,dref;
	while(fscanf(fpi,"%c",&dscan)==1){
		if(dscan>=33 && dscan<=58) dref=1; // lowercase letters
		else if(dscan>=59 && dscan<=68) dref=2; // digits
		else dref=dscan;
		switch(dref){
			case 1: {
				fprintf(fpo,"%c",dscan+64);
				break;
			}
			case 2: {
				fprintf(fpo,"%c",dscan-11);
				break;
			}
			case 69: {
				fprintf(fpo,"%c",32); // blank space
				break;
			}
			case 70: {
				fprintf(fpo,"%c",46); // period
				break;
			}
			case 71: {
				fprintf(fpo,"%c",10); // LF
				break;
			}
		}
	}
	printf("The decoding process is now complete. Please check the output file.\n");
	system("pause");
	return;			
}
