// Giaan Nguyen - 1438324
// ECE 3331 - Program 06
/* This program identifies whether a user and password is registered. If so, it will inform the user how much storage they are currently using */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int search( char x[][100], char *str, char mode );
int searchmode( char *str, int n, char c );

main()
{
	char user[20], pass[20], c; // most servers ask for usernames/passwords that are 8-20 characters in length (although one of the users has 7 chars)
	char datinfo[100][100]; // suppose there are 100 lines (users), each line having 100 chars (in case of long names, usernames, passwords)
	char last[20], first[20];	
	int i, user_no, pass_no, track=0, ulen, plen;
	float storage;
	FILE *fp;
	fp = fopen("user.pswd.txt", "r"); // read in file
	for(i=0; i<100; i++) fgets(datinfo[i], 100, fp); // store each line into datinfo[i] 
	printf("You are attempting to login to a protected system. \n\n");
	fclose(fp);
	
	login:
	printf("Please enter your username and password. \nUser: ");
	scanf("%s", user);
	user_no = search(datinfo, user, 'u');
	
	printf("Password: ");
	scanf("%s", pass);
	pass_no = search(datinfo, pass, 'p');
	
	if( ( ((user_no || pass_no) < 0) && track < 3) || (user_no != pass_no) ){
		printf("\nUsername or password is invalid. Please try again. \n\n");
		track++;
		if(track < 3) goto login;
		else{ // on third unsuccessful attempt, track increments to 3 and follows else statement
			printf("Login unsuccessful. The program will now close.\n");
			return;
		}
	}
	
	ulen=strlen(user); // number of chars in user input for username
	plen=strlen(pass); // number of chars in user input for password
	sscanf(datinfo[user_no], "%[^,], %[^,], %f, %[^,], %s", last, first, &storage, user, pass ); // %[^,] takes string up to and excluding the comma
	if( ulen != strlen(user) || plen != strlen(pass) ){ // compare number of chars in input with line
		printf("\nUsername or password is invalid. Please try again. \n\n");
		track++;
		if(track < 3) goto login;
		else{ // on third unsuccessful attempt, track increments to 3 and follows else statement
			printf("Login unsuccessful. The program will now close.\n");
			return;
		}
	}
	// if successful login:
	printf("\nWelcome back, %s! You are currently using %f KB of storage.\n", first, storage/1000.0); 
	system("pause");
}

int search( char x[][100], char *str, char mode ){
	char *istr;
	int i, count=0;
	for(i=0; i<100; i++){
		istr = strstr( x[i], str );
		if(istr == NULL) continue;
		else{
			i = searchmode(istr, i, mode);
			break;
		}
	}
	if(i==100) i=-1;
	return i;
}

int searchmode( char *str, int n, char c){
	int i,j=0, count=0;
	while(j <= strlen(str)) (str[j] == ',') ? (count++ & j++) : j++;
		if(c == 'u'){
			if(count == 1) return n; // counting number of commas in string; username onwards within line contains one comma
			else return 100; // forcing number so that search() will return -1
		}
		else if(c == 'p'){
			if(count == 0) return n; // password onwards within line contains NO commas
			else return 100;
		}
}
