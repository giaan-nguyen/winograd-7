// Giaan Nguyen - 1438324
// ECE 3331 - Program 05
#include <stdio.h>
#include <stdlib.h>
/* This program takes an input of at most 200 characters; removes e's, blank spaces, and tabs; and prints the result in reverse order. */
int removeit(char *x);
void reverseit(char *x, int k);
void printit(char *x, int k);

main()
{
	int i,total;
	char inchar[200];
	printf("This program will take the user input of characters; remove all e's, spaces, and tabs; and print the result in reverse order.\n\n");
	printf("Please input at most 200 characters:\n\n");
	
	total=removeit(inchar);
	reverseit(inchar,total);
	printit(inchar,total);
	
	system("pause");
}

int removeit(char *x){
	char c;
	int i,pos=0;
	for(i=0;i<200;i++){ // if the user inputs more than 200 chars, only the first 200 will be taken 
		c=getchar();
		if(c == 'e' || c == ' ' || c == '\t') pos++;
		else if(c =='\n'){
			x[i-pos]='\0';
			break;
		}
		else x[i-pos]=c;
	}
	return i-pos+1;
}

void reverseit(char *x, int k){
	char writeit[k]; // k total elements
	int i,pos=(k-1)-1; // (k-1) accounts for indexing, another -1 accounts for '\0' at the end
	for(i=0;i<k-1;i++){ // stop at (k-1) - also in second for loop below - so '\0' does not get overwritten
		writeit[i]=x[i+pos];
		pos-=2;
	}
	for(i=0;i<k-1;i++){
		x[i]=writeit[i];
	}
}

void printit(char *x, int k){
	int i;
	printf("\nThe modified result is as follows:\n");
	printf("\"");
	for(i=0;i<k-1;i++){ // (k-1) accounts for indexing
		printf("%c",x[i]);
	}
	printf("\"\n\n");
}
